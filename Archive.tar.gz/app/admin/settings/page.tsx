export default function SettingsPage() {
  return (
      <h1>Configurações do Sistema</h1>
  )
}